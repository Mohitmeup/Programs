import { Component, OnInit } from '@angular/core';
import { GroupStatistics } from '../model/group-statistics';
import { GroupService } from '../service/group.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {

  gstats :GroupStatistics[];

  constructor(private grpService:GroupService) {
    this.gstats=[];
   }

  ngOnInit() {
    this.grpService.getGroupStatistics().subscribe(
      (data)=>{this.gstats=data;}
    );
  }

}
