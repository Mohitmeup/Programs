package com.cg.ibs.cardmanagement.dao;



import java.math.BigDecimal;
import java.math.BigInteger;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Scanner;

import com.cg.ibs.cardmanagement.cardbean.CaseIdBean;
import com.cg.ibs.cardmanagement.cardbean.CreditCardBean;
import com.cg.ibs.cardmanagement.cardbean.CreditCardTransactionBean;
import com.cg.ibs.cardmanagement.cardbean.CustomerBean;
import com.cg.ibs.cardmanagement.cardbean.DebitCardBean;
import com.cg.ibs.cardmanagement.cardbean.DebitCardTransactionBean;


public class DaoClass  implements CustomerDao , BankDao{
	
		
	DaoClass dao = new DaoClass();
    CaseIdBean caseIdObj= new CaseIdBean();
	private static Map<String ,DebitCardTransactionBean> Debit_Card_Transaction_Details = new HashMap<String , DebitCardTransactionBean>();
	private static Map<String ,CreditCardTransactionBean> Credit_Card_Transaction_Details = new HashMap<String , CreditCardTransactionBean>();
	private static Map<String, CaseIdBean> Query_Details = new HashMap<String, CaseIdBean>();
    private static Map<String, DebitCardBean> Debit_Card_Details = new HashMap<String, DebitCardBean>();
	private static Map<String, CreditCardBean> Credit_Card_Details = new HashMap<String, CreditCardBean>();
	private static Map<BigInteger, CustomerBean> Customer_Details = new HashMap<BigInteger, CustomerBean>();
	
	 static long caseIdGenTwo=0;
		String caseIdGenOne=" ";
		  String caseIdTotal=" ";
		  
		  String addToQueryTable(String caseIdGenOne) {
				caseIdTotal = caseIdGenOne+caseIdGenTwo;
				caseIdGenTwo++;
				return caseIdTotal;
				}
	
	static{
		
		CustomerBean customer1 = new CustomerBean(new BigInteger("1234567890"),"7894561239632587","Ajay","P","ajay@gmail.com","749465231351","9942165431");
		Customer_Details.put(customer1.getAccountNumber(),customer1);
		
		DebitCardBean debit1= new DebitCardBean(new BigInteger("1234567890"), new BigInteger("1234567891012131"),true, "Ajay P", 067,1234,LocalDate.now(),"7894561239632587","Gold");
		Debit_Card_Details.put(debit1.getDebitCardNumber().toString(),debit1);
		
		//Transactions for Ajay Gold Debit Card
		DebitCardTransactionBean debittrans1 = new DebitCardTransactionBean("DEB101", "7894561239632587", new BigInteger("1234567890"), new BigInteger("1234567891012131"), 02-10-19, 1563, "Petrol", "Debit");
		DebitCardTransactionBean debittrans2 = new DebitCardTransactionBean("DEB102", "7894561239632587",new BigInteger("1234567890"), new BigInteger("1234567891012131"), 03-10-19, 20.45, "Interest", "Credit");
		Debit_Card_Transaction_Details.put(debittrans1.getTransactionid(), debittrans1);
		Debit_Card_Transaction_Details.put(debittrans2.getTransactionid(), debittrans2);
			
		CreditCardBean credit1= new CreditCardBean(new BigInteger("1234567891012132"),true, "Ajay P",623,9856,LocalDate.now(), "Platinum", "200", "100000.00", "incometax");
		Credit_Card_Details.put(credit1.getCreditCardNumber().toString(),credit1);
		
		//Transactions for Ajay Platinum Credit Card
		CreditCardTransactionBean credittrans1 = new CreditCardTransactionBean("CRED101", "7894561239632587", "1234567891012132", 01-10-19, 5000, "Shopping");
		CreditCardTransactionBean credittrans2 = new CreditCardTransactionBean("CRED102", "7894561239632587", "1234567891012132", 01-10-19, 1000, "Movie");
		Credit_Card_Transaction_Details.put(credittrans1.getTransactionid(), credittrans1);
		Credit_Card_Transaction_Details.put(credittrans2.getTransactionid(), credittrans2);
	
		CustomerBean customer2 = new CustomerBean("9876543210", "8888999666555444", "Vijay", "M", "vijay@gmail.com", "987465471230", "987654321");
		Customer_Details.put(customer2.getAccountNumber(),customer2);
		
		DebitCardBean debit2 = new DebitCardBean("9876543210", "123456789223141", true, "Vijay M", 700, 4567, LocalDate.now(), "8888999666555444", "Silver");
		Debit_Card_Details.put(debit2.getDebitCardNumber().toString(),debit2);
		
		//Transactions for Vijay Silver Debit Card
		DebitCardTransactionBean debit2trans1 = new DebitCardTransactionBean("DEB201", "8888999666555444", new BigInteger("9876543210"), new BigInteger("123456789223141"), 04-10-19, 156, "Fine", "Debit");
		DebitCardTransactionBean debit2trans2 = new DebitCardTransactionBean("DEB202", "8888999666555444",new BigInteger("9876543210"), new BigInteger("123456789223141"), 04-10-19, 203.7, "Cashback", "Credit");
		Debit_Card_Transaction_Details.put(debit2trans1.getTransactionid(), debit2trans1);
		Debit_Card_Transaction_Details.put(debit2trans2.getTransactionid(), debit2trans2);
	
	}
	
/*
	@Override
	public void viewAllQueries(CaseIdBean caseIdObj) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void newDebitCard(CaseIdBean customId, BigInteger accountNumber) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<DebitCardBean> viewAllDebitCards() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<CreditCardBean> viewAllCreditCards() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	public void newDebitCard(CaseIdBean customIdBean, BigInteger accountNumber) {
		// TODO Auto-generated method stub
		   Boolean accountNumberResult= Customer_Details.containsKey(accountNumber);
		   if(accountNumberResult) {
			   customIdBean.setAccountNumber(accountNumber);
			   
			   caseIdGenOne="ANDC";
				Date timestamp = new Date ("dd-MM-yyyy HH:mm:ss");
				
				caseIdObj.setCaseIdTotal(dao.addToQueryTable(caseIdGenOne));
				caseIdObj.setCaseTimeStamp(timestamp);
				caseIdObj.setStatusOfQuery("Pending");
				caseIdObj.setUCI(caseIdObj.getUCI());
		Query_Details.put(customIdBean.getCaseIdTotal(),customIdBean);}
		   else {
			   System.out.println("Account number does not exist");
			   
		   }
		
	}
	
	@Override
	public void viewAllQueries(CaseIdBean  caseIdObj) {
		
		
		
		}
	
	@Override
	public List<DebitCardBean> viewAllDebitCards() {
		List <DebitCardBean > debitCards = new ArrayList();
		
		
		 for(Entry<String, DebitCardBean> entry:Debit_Card_Details.entrySet()) {
		debitCards.add(entry.getValue());}
		return debitCards;
		  
		
	}
	
	public List<CreditCardBean> viewAllCreditCards() {
		List <CreditCardBean > creditCards = new ArrayList();
		
		
		 for(Entry<String, CreditCardBean> entry:Credit_Card_Details.entrySet()) {
		creditCards.add(entry.getValue());}
		return creditCards;
		  


*/



}