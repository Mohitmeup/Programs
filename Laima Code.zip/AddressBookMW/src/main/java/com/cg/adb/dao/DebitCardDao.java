package com.cg.adb.dao;

import java.math.BigInteger;
import java.util.List;

import com.cg.adb.exception.IBSException;
import com.cg.adb.model.CaseIdBean;
import com.cg.adb.model.DebitCardBean;


public interface DebitCardDao {


	List<DebitCardBean> viewAllDebitCards();

	DebitCardBean getDebitdetails(BigInteger debitCardNumber) throws IBSException;

	String getDebitCardStatus(BigInteger debitCardNumber)throws IBSException;

	Object getDebitCardPin(BigInteger debitCardNumber)throws IBSException;

	void blockDebitCard(BigInteger debitCardNumber)throws IBSException;

	void setNewDebitPin(BigInteger debitCardNumber, String pin)throws IBSException;

	String getdebitCardType(BigInteger debitCardNumber)throws IBSException;

	BigInteger getAccountNumber(BigInteger cardNumber)throws IBSException;

	BigInteger getApplicationId()throws IBSException;

	BigInteger getUci(BigInteger accountNumber)throws IBSException;

	//void actionServiceRequest(CaseIdBean caseIdObj)throws IBSException;

	


}
