package com.cg.adb.model;

public enum DebitCardStatus {
	BLOCKED,ACTIVE,INACTIVE

}
