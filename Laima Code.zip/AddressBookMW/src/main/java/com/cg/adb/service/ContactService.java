package com.cg.adb.service;

import java.math.BigInteger;
import java.util.List;

import com.cg.adb.exception.AdbException;
import com.cg.adb.exception.IBSException;
import com.cg.adb.model.ContactModel;
import com.cg.adb.model.DebitCardBean;
import com.cg.adb.model.GroupStatistics;

public interface ContactService {
	ContactModel add(ContactModel group) throws AdbException;
	ContactModel save(ContactModel group) throws AdbException;
	void delete(Long contactId) throws AdbException;
	ContactModel findById(Long contactId);
	List<ContactModel> findAll();
	List<GroupStatistics> findGroupCount();
	List<DebitCardBean> viewAllSortedDebitCards() throws AdbException;
	DebitCardBean fetchDebitdetails(BigInteger cardNumber) throws IBSException;
	boolean verifyDebitCardPin(String pin) throws IBSException;
	String getDebitcardStatus(BigInteger cardNumber) throws IBSException;
	boolean verifyDebitPin(String pin, BigInteger cardNumber)throws IBSException;
	void requestDebitCardLost(BigInteger cardNumber)throws IBSException;
	void resetDebitPin(BigInteger cardNumber, String newpin) throws IBSException;
	String getDebitcardType(BigInteger cardNumber)throws IBSException;
	//String requestDebitCardUpgrade(BigInteger cardNumber, String type, String remarks) throws IBSException;
//	String addToServiceRequestTable(String caseIdGenOne);

}
