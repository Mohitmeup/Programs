package com.cg.adb.service;

import java.math.BigInteger;
import java.sql.Date;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.adb.dao.ContactRepository;
import com.cg.adb.dao.DebitCardDao;
import com.cg.adb.dao.GroupRepository;
import com.cg.adb.entity.ContactEntity;
import com.cg.adb.exception.AdbException;
import com.cg.adb.exception.ErrorMessages;
import com.cg.adb.exception.IBSException;
import com.cg.adb.model.Banker;
import com.cg.adb.model.CaseIdBean;
import com.cg.adb.model.ContactModel;
import com.cg.adb.model.CustomerBean;
import com.cg.adb.model.DebitCardBean;
import com.cg.adb.model.GroupStatistics;



@Service
public class ContactServiceImpl implements ContactService {

	@Autowired
	private ContactRepository contactRepo;

	@Autowired
	private GroupRepository grpRepo;
	
	@Autowired
	private DebitCardDao dcd;

	private ContactModel valueOf(ContactEntity entity) {
		ContactModel model = new ContactModel();

		model.setContactId(entity.getContactId());
		model.setFirstName(entity.getFirstName());
		model.setMiddleName(entity.getMiddleName());
		model.setLastName(entity.getLastName());
		model.setGender(entity.getGender());
		model.setDateOfBirth(entity.getDateOfBirth());
		model.setMobileNumber(entity.getMobileNumber());
		model.setMailId(entity.getMailId());
		model.setWhatsAppNumber(entity.getWhatsAppNumber());
		model.setFaceBookId(entity.getFaceBookId());
		if (entity.getGroup() != null) {
			model.setGroupName(entity.getGroup().getGroupName());
		}
		return model;
	}

	private ContactEntity valueOf(ContactModel model) {
		ContactEntity entity = new ContactEntity();

		entity.setContactId(model.getContactId());
		entity.setFirstName(model.getFirstName());
		entity.setMiddleName(model.getMiddleName());
		entity.setLastName(model.getLastName());
		entity.setGender(model.getGender());
		entity.setDateOfBirth(model.getDateOfBirth());
		entity.setMobileNumber(model.getMobileNumber());
		entity.setMailId(model.getMailId());
		entity.setWhatsAppNumber(model.getWhatsAppNumber());
		entity.setFaceBookId(model.getFaceBookId());
		if (null != model.getGroupName() && model.getGroupName().trim().length() > 0) {
			entity.setGroup(grpRepo.findByGroupName(model.getGroupName()));
		}

		return entity;
	}

	@Override
	public ContactModel add(ContactModel contact) throws AdbException {
		return valueOf(contactRepo.save(valueOf(contact)));
	}

	@Override
	public ContactModel save(ContactModel contact) throws AdbException {

		ContactModel model = null;

		if (!contactRepo.existsById(contact.getContactId())) {
			throw new AdbException("Contact#" + contact.getContactId() + " not found");
		}

		model = valueOf(contactRepo.save(valueOf(contact)));

		return model;
	}

	@Override
	public void delete(Long contactId) throws AdbException {

		if (!contactRepo.existsById(contactId)) {
			throw new AdbException("Contact#" + contactId + " not found");
		}

		contactRepo.deleteById(contactId);

	}

	@Override
	public ContactModel findById(Long contactId) {
		Optional<ContactEntity> entity = contactRepo.findById(contactId);
		return entity.isPresent() ? valueOf(entity.get()) : null;
	}

	@Override
	public List<ContactModel> findAll() {
		List<ContactModel> models = null;

		List<ContactEntity> entities = contactRepo.findAll();

		if (null != entities && entities.size() > 0) {
			models = new ArrayList<ContactModel>();
			for (ContactEntity entity : entities) {
				models.add(valueOf(entity));
			}
		}

		return models;
	}

	@Override
	public List<GroupStatistics> findGroupCount() {
		return contactRepo.findGroupCount();
	}
	@Override
	public List<DebitCardBean> viewAllSortedDebitCards() throws AdbException {
		List<DebitCardBean> list = null;
		try {
			list = dcd.viewAllDebitCards();
			System.out.println(list);
		} catch (NullPointerException e) {
			throw new AdbException(e.getMessage());
		}
		return list;
	}

	@Override
	public DebitCardBean fetchDebitdetails(BigInteger debitCardNumber) throws IBSException {
		return dcd.getDebitdetails(debitCardNumber);
	}
	@Override
	public boolean verifyDebitCardPin(String pin)throws IBSException {

		boolean check = true;
		Pattern pattern = Pattern.compile("[0-9]{4}");
		Matcher matcher = pattern.matcher(pin);
		if (!(matcher.find() && matcher.group().equals(pin))) {
			check = false;
			throw new IBSException("Incorrect format of pin");
		}

		return check;
	}
	
	@Override
	public String getDebitcardStatus(BigInteger debitCardNumber) throws IBSException {
		String status;

		try {
			status = dcd.getDebitCardStatus(debitCardNumber);
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

		return status;

	}

	@Override
	public boolean verifyDebitPin(String pin, BigInteger debitCardNumber) throws IBSException {
		try {

			if (pin.equals(dcd.getDebitCardPin(debitCardNumber))) {
				return true;
			} else {
				return false;
			}
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}
	}
	@Transactional
	@Override
	public void resetDebitPin(BigInteger debitCardNumber, String pin) throws IBSException {
		try {

			dcd.setNewDebitPin(debitCardNumber, pin);

		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

	}

	@Override
	@Transactional
	public void requestDebitCardLost(BigInteger debitCardNumber) throws IBSException {

		try {
			dcd.blockDebitCard(debitCardNumber);
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());

		}

	}

	@Override
	public String getDebitcardType(BigInteger debitCardNumber) throws IBSException {
		String type;

		try {
			type = dcd.getdebitCardType(debitCardNumber);
		} catch (IBSException e) {
			throw new IBSException(e.getMessage());
		}

		return type;

	}
	/*
	 * @Override public String addToServiceRequestTable(String caseIdGenOne) { //
	 * logger.info("entered into addToServiceRequestTable method of //
	 * CustomerServiceImpl class"); Date dNow = Date.valueOf(LocalDate.now());
	 * SimpleDateFormat ftDateFormat = new SimpleDateFormat("yyMMddhhmmssS"); String
	 * dateString = ftDateFormat.format(dNow);
	 * 
	 * 
	 * 
	 * String caseIdTotal = caseIdGenOne + dateString;
	 * 
	 * 
	 * 
	 * return caseIdTotal; }
	 */
	/*
	 * @Override public String requestDebitCardUpgrade(BigInteger cardNumber, String
	 * type, String remarks) throws IBSException { CaseIdBean caseIdObj = new
	 * CaseIdBean(); String caseIdGenOne = "RDCU";
	 * 
	 * Random random = new Random(); LocalDateTime timestamp = LocalDateTime.now();
	 * String caseIdTotal = addToServiceRequestTable(caseIdGenOne); String
	 * customerReferenceID = (caseIdTotal + random.nextInt(100));
	 * caseIdObj.setRequestMap("RDCU"); caseIdObj.setCaseIdTotal(caseIdTotal);
	 * caseIdObj.setCaseTimeStamp(timestamp);
	 * caseIdObj.setStatusOfServiceRequest("Pending");
	 * caseIdObj.setCardNumber(cardNumber); caseIdObj.setCustomerRemarks(remarks);
	 * caseIdObj.setCustomerReferenceId(customerReferenceID); BigInteger
	 * accountNumber = dcd.getAccountNumber(cardNumber); BigInteger applicationID =
	 * dcd.getApplicationId();
	 * 
	 * 
	 * 
	 * applicationID = applicationID.add(new BigInteger("1")); Banker banker = new
	 * Banker(); banker.setBankerId(getBankbankerId(applicationID));
	 * caseIdObj.setBanker(banker); caseIdObj.setApplicationId(applicationID);
	 * caseIdObj.setAccountNumber(accountNumber);
	 * 
	 * 
	 * 
	 * CustomerBean custom = new CustomerBean();
	 * custom.setUCI(dcd.getUci(accountNumber));
	 * caseIdObj.setCustomerBeanObject(custom);
	 * 
	 * 
	 * 
	 * caseIdObj.setDefineServiceRequest(type);
	 * 
	 * 
	 * 
	 * try {
	 * 
	 * 
	 * 
	 * dcd.actionServiceRequest(caseIdObj);
	 * 
	 * 
	 * 
	 * } catch (IBSException e) { throw new IBSException(e.getMessage()); }
	 * 
	 * 
	 * 
	 * return (customerReferenceID); }
	 */
}
