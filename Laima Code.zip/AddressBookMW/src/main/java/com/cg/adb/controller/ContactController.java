package com.cg.adb.controller;

import java.math.BigInteger;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.adb.exception.AdbException;
import com.cg.adb.exception.IBSException;
import com.cg.adb.model.AccBean;
import com.cg.adb.model.CardDetails;
import com.cg.adb.model.ContactModel;
import com.cg.adb.model.DebitCardBean;
import com.cg.adb.service.ContactService;

@RestController
@RequestMapping("/contact")
@CrossOrigin
public class ContactController {
	@Autowired
	private ContactService contactService;

	@GetMapping
	public ResponseEntity<List<ContactModel>> getAllContacts() {
		return new ResponseEntity<List<ContactModel>>(contactService.findAll(), HttpStatus.OK);
	}
	
	@PatchMapping(value = "/block")
	public ResponseEntity<CardDetails> block(@RequestBody DebitCardBean debitBeanObj) throws IBSException {
		String pin=debitBeanObj.getCurrentPin();
		BigInteger cardNumber=debitBeanObj.getCardNumber();
	
		CardDetails output = new CardDetails();
		
		if (contactService.verifyDebitCardPin(pin)) {
			if (!contactService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Blocked")) {
				if (contactService.verifyDebitPin(pin, cardNumber)) {
					
					contactService.requestDebitCardLost(cardNumber);
					output.setMessage(" Your card has been Blocked. Contact branch for further process!" );
					output.setValue(true);
					

				} else {
					output.setMessage("Card number and pin don't match!! Try again!"  );
					output.setValue(false);
				}
			} else {

				output.setMessage(" Card already blocked" );
				output.setValue(false);
			}
		} else {
			output.setMessage("Invalid pin format");
			output.setValue(false);


		}

		return new ResponseEntity<CardDetails>(output, HttpStatus.OK);

	}
	
	@PostMapping(value = "/reset") 
    public ResponseEntity<CardDetails> resetPin(@RequestBody DebitCardBean d) throws IBSException {
        CardDetails output = new CardDetails();
        String pin = d.getCurrentPin();
        BigInteger cardNumber = d.getCardNumber();
        System.out.println(pin);
     System.out.println("fvbdfv"+d);
            if (contactService.verifyDebitPin(pin, cardNumber)) {
               
                output.setMessage("PIN VERIFIED");
                output.setValue(true);
            } else {
                
                output.setMessage( "PINS DO NOT MATCH!! TRY AGAIN");
                output.setValue(false);
            }
            
            return new ResponseEntity<CardDetails>(output, HttpStatus.OK);
    }
    
    
    
    
    @PatchMapping(value = "/resetpin")
    public ResponseEntity<CardDetails> resetPin2(@RequestBody DebitCardBean d) throws IBSException {
        CardDetails output = new CardDetails();
        BigInteger cardNumber = d.getCardNumber();
        String newpin = d.getCurrentPin();
        System.out.println("fdg"+newpin);
        System.out.println("fvbfgdfgghfdfv"+d);
           // if (newpin2.equals(newpin)) {
        contactService.resetDebitPin(cardNumber, newpin);
                output.setMessage("PIN SUCCESSFULLY CHANGED");
                output.setValue(true);
           
            return new ResponseEntity<CardDetails>(output, HttpStatus.OK);
       
    }
	
	
	
	
	
	
	
	
	
	

	@GetMapping("/debitlist")
	public ResponseEntity<List<DebitCardBean>> list() throws AdbException {
		System.out.println("abhcbskdbfhb");
		// List<DebitCardBean>debitCardBeans = debitService.viewAllDebitCards();
		List<DebitCardBean> debitCardBeansSorted = contactService.viewAllSortedDebitCards();
		System.out.println(debitCardBeansSorted.toString());
		return new ResponseEntity<List<DebitCardBean>>(debitCardBeansSorted, HttpStatus.OK);
	}
	@GetMapping("/carddisplaymenu")
	public ResponseEntity<DebitCardBean> cardDetails(@RequestBody Debi contact) throws IBSException {
		DebitCardBean object = contactService.fetchDebitdetails(cardNumber);

		return new ResponseEntity<DebitCardBean>(object, HttpStatus.OK);
	}

	@GetMapping("/{contactId}")
	public ResponseEntity<ContactModel> getGroupById(@PathVariable("contactId") Long contactId) {
		ResponseEntity<ContactModel> result = null;

		ContactModel model = contactService.findById(contactId);

		if (null == model) {
			result = new ResponseEntity<>(HttpStatus.NOT_FOUND);
		} else {
			result = new ResponseEntity<>(model, HttpStatus.OK);
		}

		return result;
	}

	@PostMapping
	public ResponseEntity<ContactModel> addGroup(@RequestBody ContactModel contact) throws AdbException {
		ResponseEntity<ContactModel> result = null;

		ContactModel model = contactService.add(contact);
		result = new ResponseEntity<>(model, HttpStatus.OK);

		return result;
	}

	@PutMapping
	public ResponseEntity<ContactModel> saveGroup(@RequestBody ContactModel contact) throws AdbException {
		ResponseEntity<ContactModel> result = null;

		ContactModel model = contactService.save(contact);
		result = new ResponseEntity<>(model, HttpStatus.OK);

		return result;
	}

	@PostMapping(value = "/upgrade1")
	    public  ResponseEntity<CardDetails> upgrade(@RequestBody DebitCardBean d) throws IBSException  {
		System.out.println(d);
	        CardDetails output = new CardDetails();
	        String type = null;
	        BigInteger cardNumber = d.getCardNumber();
	        System.out.println(cardNumber);
	        System.out.println(type);
	        
	            if (!contactService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Blocked")
	                    && !contactService.getDebitcardStatus(cardNumber).equalsIgnoreCase("Inactive")) {
	                type = contactService.getDebitcardType(cardNumber);
	                if (type.equalsIgnoreCase("Silver")) {
	                    output.setFlag(1);
	                    output.setMessage("Silver");
	                } else if (type.equalsIgnoreCase("Gold")) {
	                     output.setFlag(2);
	                     output.setMessage("Gold");
	                } else {
	                     output.setFlag(3);
	                     output.setMessage("Platinium");
	                }
	                output.setValue(true);
	                
	            } else {
	                output.setFlag(0);
	                output.setMessage( "OOPS!!  You can not upgrade a blocked/inactive card");
	                output.setValue(false);
	            }
	           


	 
	                return new ResponseEntity<CardDetails>(output, HttpStatus.OK);


	    }


//	@PostMapping(value = "/upgradeTwo")
//    public  ResponseEntity<CardDetails> upgrade2(@RequestBody AccBean a) throws IBSException {
//        CardDetails output = new CardDetails();
//       
//        BigInteger cardNumber = a.getCardNumber();
//        String type=a.getType();
//        String remarks=a.getRemarks();
//        
//            String num = contactService.requestDebitCardUpgrade(cardNumber, type, remarks);
//
//
//
//            output.setMessage("Ticket Raised successfully. Your reference Id is" + num);
//            output.setValue(true);
//            
//            return new ResponseEntity<CardDetails>(output, HttpStatus.OK);
//
//
//
//    }


	@DeleteMapping("/{groupId}")
	public ResponseEntity<Void> deleteGroupById(@PathVariable("contactId") Long contactId) throws AdbException {
		contactService.delete(contactId);
		return new ResponseEntity<Void>(HttpStatus.OK);
	}

	@ExceptionHandler(AdbException.class)
	public ResponseEntity<String> handleAdbException(AdbException exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.BAD_REQUEST);
	}

	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> handleException(Exception exp) {
		return new ResponseEntity<String>(exp.getMessage(), HttpStatus.INTERNAL_SERVER_ERROR);
	}
}
