package com.cg.adb.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.adb.dao.GroupRepository;
import com.cg.adb.entity.GroupEntity;
import com.cg.adb.exception.AdbException;
import com.cg.adb.model.GroupModel;

@Service
@Transactional
public class GroupServiceImpl implements GroupService {
	
	@Autowired
	private GroupRepository grpRepo;

	private GroupModel valueOf(GroupEntity entity) {
		GroupModel model = new GroupModel();
		model.setGroupId(entity.getGroupId());
		model.setGroupName(entity.getGroupName());
		model.setDescription(entity.getDescription());
		return model;
	}
	
	private GroupEntity valueOf(GroupModel model) {
		GroupEntity entity = new GroupEntity();
		entity.setGroupId(model.getGroupId());
		entity.setGroupName(model.getGroupName());
		entity.setDescription(model.getDescription());
		return entity;
	}
	
	@Override
	public GroupModel add(GroupModel group) throws AdbException {
		GroupModel model=null;		
		
		if(grpRepo.existsByGroupName(group.getGroupName())) {
			throw new AdbException("Group already exists");
		}
						
		model = valueOf(grpRepo.save(valueOf(group)));
		return model;
	}

	@Override
	public GroupModel save(GroupModel group) throws AdbException{
		GroupModel model=null;		
		
		if(!grpRepo.existsById(group.getGroupId())) {
			throw new AdbException("Group does not exist");
		}
						
		model = valueOf(grpRepo.save(valueOf(group)));
		return model;
	}

	@Override
	public void delete(Long groupId) throws AdbException{
		if(!grpRepo.existsById(groupId)) {
			throw new AdbException("Group does not exist");
		}

		grpRepo.deleteById(groupId);
	}

	@Override
	public GroupModel findById(Long groupId) {
		Optional<GroupEntity> entity = grpRepo.findById(groupId);
		return entity.isPresent()? valueOf(entity.get()):null;
	}

	@Override
	public List<GroupModel> findAll() {
		
		List<GroupModel> models=null;
		List<GroupEntity> entities =grpRepo.findAll(); 
		
		if(null!=entities && entities.size()>0) {
			models = new ArrayList<>();
			for(GroupEntity entity : entities) {
				models.add(valueOf(entity));
			}
		}
		
		return models;
	}

}
