package com.cg.adb.model;

public class GroupStatistics {

	private String groupName;
	private Long count;
	public GroupStatistics(String groupName, Long count) {
		super();
		this.groupName = groupName;
		this.count = count;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public Long getCount() {
		return count;
	}
	public void setCount(Long count) {
		this.count = count;
	}
	
	
}
