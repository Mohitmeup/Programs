package com.cg.adb.service;

import java.util.List;

import com.cg.adb.exception.AdbException;
import com.cg.adb.model.GroupModel;

public interface GroupService {

	GroupModel add(GroupModel group) throws AdbException;
	GroupModel save(GroupModel group) throws AdbException;
	void delete(Long groupId) throws AdbException;
	GroupModel findById(Long groupId);
	List<GroupModel> findAll();
	
}
