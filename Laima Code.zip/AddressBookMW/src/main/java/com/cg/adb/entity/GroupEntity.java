package com.cg.adb.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Groups")
public class GroupEntity {

	@Id
	@Column(name="gid")
	@GeneratedValue(strategy = GenerationType.SEQUENCE,generator = "GID_SEQ_GEN")
	@SequenceGenerator(name="GID_SEQ_GEN",sequenceName = "SEQ_GID",initialValue = 1,allocationSize = 1)
	private Long groupId;
	
	@Column(name="gnm",nullable = false)
	private String groupName;
	
	@Column(name="desp")
	private String description;

	@OneToMany(cascade = CascadeType.PERSIST,mappedBy = "group")
	private Set<ContactEntity> contacts;
	
	
	public Long getGroupId() {
		return groupId;
	}

	public void setGroupId(Long groupId) {
		this.groupId = groupId;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Set<ContactEntity> getContacts() {
		return contacts;
	}

	public void setContacts(Set<ContactEntity> contacts) {
		this.contacts = contacts;
	}

	
}
