package com.cg.adb.model;

public enum CreditCardStatus {

		 PENDING, BLOCKED,ACTIVE,INACTIVE
		
}
