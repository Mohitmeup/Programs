package com.cg.adb.dao;

import java.math.BigInteger;
import java.util.Collections;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.adb.exception.ErrorMessages;
import com.cg.adb.exception.IBSException;
import com.cg.adb.model.DebitCardBean;
import com.cg.adb.model.DebitCardStatus;

@Repository
public class DebitCardDaoImpl implements DebitCardDao {
	// private static Logger logger = Logger.getLogger(DebitCardDaoImpl.class);
	@PersistenceContext
	private EntityManager entityManager;

	DebitCardBean bean = new DebitCardBean();

	@Override
	public List<DebitCardBean> viewAllDebitCards() {
		TypedQuery<DebitCardBean> debitQuery = entityManager.createQuery("select d from DebitCardBean d",
				DebitCardBean.class);
		System.out.println(debitQuery.getResultList());
		return debitQuery.getResultList();
	}
	@Override
	public DebitCardBean getDebitdetails(BigInteger debitCardNumber) {
			Query cardQuery = entityManager.createQuery("select d from DebitCardBean d WHERE d.cardNumber = :dcn");
			cardQuery.setParameter("dcn", debitCardNumber);
			bean = (DebitCardBean) cardQuery.getSingleResult();
		return bean;
	}
	@Override
	public String getDebitCardPin(BigInteger debitCardNumber) throws IBSException {
		// logger.info("entered into getDebitCardPin method of DebitCardDaoImpl class");
		String debitPin = null;
		try {
			TypedQuery<String> query = entityManager.createQuery(
					"select d.currentPin from DebitCardBean d where d.cardNumber=:debitCardNum", String.class);
			query.setParameter("debitCardNum", debitCardNumber);
			debitPin = query.getSingleResult();

			System.out.println(debitPin);
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);
		}

		return debitPin;
	}
	@Override
	public String getDebitCardStatus(BigInteger debitCardNumber) throws IBSException {
		
		String query1 = null;
		try {

			DebitCardBean d = entityManager.find(DebitCardBean.class, debitCardNumber);

			query1 = d.getCardStatus().toString();

		} catch (NullPointerException e) {
			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);
		}
		return query1;
	}

	@Override
	@Transactional
	public void blockDebitCard(BigInteger debitCardNumber) throws IBSException {

		DebitCardBean cardBean = null;

		try {
			cardBean = entityManager.find(DebitCardBean.class, debitCardNumber);
			if (cardBean.getCardStatus().toString().equalsIgnoreCase("Blocked"))
				throw new IBSException("Card Already Blocked");

			cardBean.setCardStatus(DebitCardStatus.BLOCKED);

		} catch (NullPointerException e) {
			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);
		}

		}
	@Transactional
	@Override
	public void setNewDebitPin(BigInteger debitCardNumber, String newPin) throws IBSException {
		// logger.info("entered into setNewDebitPin method of DebitCardDaoImpl class");
		DebitCardBean cardBean = null;
		try {
			cardBean = entityManager.find(DebitCardBean.class, debitCardNumber);

			cardBean.setCurrentPin(newPin);

		} catch (NullPointerException e) {
			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);
		}

	}
	@Override
	public String getdebitCardType(BigInteger debitCardNumber) throws IBSException {
		// logger.info("entered into getDebitCardType method of DebitCardDaoImpl
		// class");
		String cardType = null;
		try {
			TypedQuery<String> query = entityManager.createQuery(
					"select d.cardType from DebitCardBean d where d.cardNumber=:debitCardNum", String.class);
			query.setParameter("debitCardNum", debitCardNumber);
			cardType = query.getSingleResult();
		} catch (NoResultException e) {
			throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);
		}
		return cardType;

	}
	@Override
	public BigInteger getAccountNumber(BigInteger cardNumber) throws IBSException {
		// logger.info("entered into getAccountNumber method of DebitCardDaoImpl
        // class");
        BigInteger accountNum = null;
        try {
            TypedQuery<BigInteger> query = entityManager.createQuery(
                    "select a.accountNumber from DebitCardBean d INNER JOIN d.accountBeanObject a where d.cardNumber=:cardNum",
                    BigInteger.class);
            query.setParameter("cardNum", cardNumber);
            accountNum = query.getSingleResult();

 

        } catch (NoResultException e) {
            // logger.error(e);
            throw new IBSException(ErrorMessages.DEB_CARD_NOT_EXIST_MESSAGE);

 

        }
        return accountNum;
	}
	@Override
	public BigInteger getApplicationId() throws IBSException {
		 BigInteger applicationId = new BigInteger("0");

		 

	        try {
	            TypedQuery<BigInteger> query = entityManager.createQuery(SqlQueries.SELECT_LAST_APPLICATION_ID,
	                    BigInteger.class);

	 

	            List<BigInteger> applicationId1 = query.getResultList();
	            System.out.println(applicationId1);
	            applicationId = Collections.max(applicationId1);
	            System.out.println(applicationId);
	        } catch (NoResultException e) {
	            throw new IBSException(ErrorMessages.NO_QUERIES);
	        }

	 

	        return applicationId;
	}
//	@Override
//	public BigInteger getUci(BigInteger accountNumber) throws IBSException {
//		
//	}
	@Override
	public BigInteger getUci(BigInteger accountNumber) throws IBSException {
		// TODO Auto-generated method stub
		return null;
	}

}
