
greet = function(userName="Srinu"){
    console.log("Hello " + userName);
}

//greet("Vamsy");

setTimeout(greet,2000);

console.log("Program Terminated");