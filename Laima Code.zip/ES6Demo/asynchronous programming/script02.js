
greet = function(userName="Srinu"){
    console.log("Hello " + userName);
}

setInterval(() => {greet("RAM");},2000);

console.log("Program Terminated");