package com.cg.ibs.cardmanagement.cardbean;

public class CreditCardTransaction {
   
}
