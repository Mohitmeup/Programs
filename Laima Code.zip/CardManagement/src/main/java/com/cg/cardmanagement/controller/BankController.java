package com.cg.cardmanagement.controller;

import java.math.BigInteger;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.cardmanagement.exception.IBSException;
import com.cg.cardmanagement.model.CaseIdBean;
import com.cg.cardmanagement.model.CreditCardTransaction;
import com.cg.cardmanagement.model.Transaction;
import com.cg.cardmanagement.service.BankService;

@RestController
@RequestMapping("/banker")
public class BankController {

	@Autowired
	private BankService bankService;

	@GetMapping(value = "/viewNewdebit/{bankerId}")
	public ResponseEntity<List<CaseIdBean>> listNewDebitQueries(@PathVariable("bankerId") Integer bankerId)
			throws IBSException {

		List<CaseIdBean> caseBeans = bankService.viewNewDebitQueries(bankerId);
		return new ResponseEntity<List<CaseIdBean>>(caseBeans, HttpStatus.OK);

	}

	@GetMapping("/viewDebitmismatch/{bankerId}")
	public ResponseEntity<List<CaseIdBean>> debitMismatch(@PathVariable("bankerId") Integer bankerId)
			throws IBSException {

		List<CaseIdBean> caseBeans = bankService.viewDebitMismatchQueries(bankerId);
		return new ResponseEntity<List<CaseIdBean>>(caseBeans, HttpStatus.OK);

	}

	@GetMapping("/viewCreditmismatch/{bankerId}")
	public ResponseEntity<List<CaseIdBean>> creditMismatch(@PathVariable("bankerId") Integer bankerId)
			throws IBSException {

		List<CaseIdBean> caseBeans = bankService.viewCreditMismatchQueries(bankerId);
		return new ResponseEntity<List<CaseIdBean>>(caseBeans, HttpStatus.OK);

	}

	@GetMapping("/debitQueriesMismatch/{serviceRequest}")
	public ResponseEntity<Transaction> replyDebitQueriesMismatch(@PathVariable("serviceRequest") String serviceRequest)
			throws IBSException {

		BigInteger mismatchTransactionId = bankService.getDebitTransactionId(serviceRequest);

		Transaction debitCardBeanTrns = bankService.getDebitMismatchTransaction(mismatchTransactionId);
		bankService.setBankTimeStamp(serviceRequest);
		return new ResponseEntity<Transaction>(debitCardBeanTrns, HttpStatus.OK);

	}

	@GetMapping("/creditQueriesMismatch/{serviceRequest}")
	public ResponseEntity<CreditCardTransaction> replyCreditQueriesMismatch(
			@PathVariable("serviceRequest") String serviceRequest) throws IBSException {

		BigInteger mismatchTransactionId = bankService.getCreditTransactionId(serviceRequest);
		CreditCardTransaction creditCardBeanTrns = bankService.getCreditMismatchTransaction(mismatchTransactionId);
		bankService.setBankTimeStamp(serviceRequest);
		return new ResponseEntity<CreditCardTransaction>(creditCardBeanTrns, HttpStatus.OK);

	}

	@PutMapping("/mismatchDebitBlock/{cardNum}/{answer}")
	public ResponseEntity<String> replyQueriesDebit(@PathVariable("cardNum") BigInteger debitCardNumber,
			@PathVariable("answer") String answer) throws IBSException {
		if (answer.equalsIgnoreCase("Yes")) {
			bankService.blockDebit(debitCardNumber);

			String output = "You card has been blocked successfully.";
			return new ResponseEntity<String>(output, HttpStatus.OK);
		} else {
			String output = "You have chosen no.";
			return new ResponseEntity<String>(output, HttpStatus.OK);
		}

	}

	@PutMapping("/mismatchCreditBlock/{cardNum}/{answer}")
	public ResponseEntity<String> replyQueriesCredit(@PathVariable("cardNum") BigInteger creditCardNumber,
			@PathVariable("answer") String answer) throws IBSException {
		if (answer.equalsIgnoreCase("Yes")) {
			bankService.blockCredit(creditCardNumber);
			String output = "You card has been blocked successfully.";
			return new ResponseEntity<String>(output, HttpStatus.OK);
		} else {
			String output = "You have chosen no.";
			return new ResponseEntity<String>(output, HttpStatus.OK);
		}
	}

	@PostMapping(value = "/replyQueries")
	public ResponseEntity<String> replyQueries(@RequestBody CaseIdBean caseIdBean) throws IBSException {

		String serviceRequest = caseIdBean.getCaseIdTotal();
		String status = caseIdBean.getStatusOfServiceRequest();
		String remarks = caseIdBean.getBankAdminRemarks();

		bankService.setQueryStatus(serviceRequest, status, remarks);
		String output = "Replied successfully to the query";
		return new ResponseEntity<String>(output, HttpStatus.OK);

	}

	@GetMapping(value = "/viewNewcredit/{bankerId}")
	public ResponseEntity<List<CaseIdBean>> listNewCreditQueries(@PathVariable("bankerId") Integer bankerId)
			throws IBSException {
		List<CaseIdBean> caseBeans = bankService.viewNewCreditQueries(bankerId);
		return new ResponseEntity<List<CaseIdBean>>(caseBeans, HttpStatus.OK);

	}

	@GetMapping(value = "/viewUpgradeDebit/{bankerId}")
	public ResponseEntity<List<CaseIdBean>> listNewUpgradeDebitQueries(@PathVariable("bankerId") Integer bankerId)
			throws IBSException {
		List<CaseIdBean>

		caseBeans = bankService.viewDebitUpgradeQueries(bankerId);
		return new ResponseEntity<List<CaseIdBean>>(caseBeans, HttpStatus.OK);
	}

	@GetMapping(value = "/viewUpgradeCredit/{bankerId}")
	public ResponseEntity<List<CaseIdBean>> listNewUpgradeCreditQueries(@PathVariable("bankerId") Integer bankerId)
			throws IBSException {
		List<CaseIdBean> caseBeans = bankService.viewCreditUgradeQueries(bankerId);
		return new ResponseEntity<List<CaseIdBean>>(caseBeans, HttpStatus.OK);

	}

	@ExceptionHandler
	public ResponseEntity<String> ibsException(IBSException e) {

		String output = e.getMessage();
		return new ResponseEntity<String>(output, HttpStatus.OK);
	}

	@GetMapping(value = "/viewCustomerHistory/{uci}")
	public ResponseEntity<List<CaseIdBean>> listCustomerHistory(@PathVariable("uci") BigInteger uci)
			throws IBSException {
		List<CaseIdBean> caseBeans = bankService.viewCustomerHistory(uci);

		return new ResponseEntity<List<CaseIdBean>>(caseBeans, HttpStatus.OK);

	}

}
