package com.cg.ibs.cardmanagement.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.ResourceBundle;

public class ConnectionUtil {

	private static Connection connection;

	public static Connection getConnection() {
		if (connection == null) {
			ResourceBundle bundle = ResourceBundle.getBundle("db");
			String url = bundle.getString("url");
			String username = bundle.getString("user");
			String password = bundle.getString("password");
			try {
				connection = DriverManager.getConnection(url, username, password);
			} catch (Exception e) {

			}
		}
		return connection;
	}

}
