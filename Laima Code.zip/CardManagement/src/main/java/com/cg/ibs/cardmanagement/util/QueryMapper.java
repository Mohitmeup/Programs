package com.cg.ibs.cardmanagement.util;

public interface QueryMapper {
public String verifyAccountNumber = "SELECT "
}
