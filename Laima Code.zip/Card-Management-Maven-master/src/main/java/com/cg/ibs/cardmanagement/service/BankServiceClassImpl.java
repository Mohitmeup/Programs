package com.cg.ibs.cardmanagement.service;

import java.math.BigInteger;
import java.util.List;
import java.util.Random;

import com.cg.ibs.cardmanagement.bean.CaseIdBean;
import com.cg.ibs.cardmanagement.bean.CreditCardTransaction;
import com.cg.ibs.cardmanagement.bean.DebitCardTransaction;
import com.cg.ibs.cardmanagement.dao.BankDao;
import com.cg.ibs.cardmanagement.dao.CardManagementDaoImpl;

public class BankServiceClassImpl implements BankService {

	BankDao bankDao = new CardManagementDaoImpl();
	CaseIdBean caseIdObj = new CaseIdBean();

	@Override
	public List<CaseIdBean> viewQueries() {

		List<CaseIdBean> caseBeans = bankDao.viewAllQueries();

		return bankDao.viewAllQueries();

	}

	@Override
	public List<DebitCardTransaction> getDebitTrns(int days, BigInteger debitCardNumber) {

		boolean check = bankDao.verifyDebitCardNumber(debitCardNumber);
		if (check) {
			if (days >= 1) {

				return bankDao.getDebitTrans(days, debitCardNumber);
			} else {
				return null;
			}

		} else {
			return null;
		}
	}

	@Override
	public List<CreditCardTransaction> getCreditTrans(int days, BigInteger creditCardNumber) {

		boolean check = bankDao.verifyCreditCardNumber(creditCardNumber);
		if (check) {
			if (days >= 1) {

				return bankDao.getCreditTrans(days, creditCardNumber);
			} else {
				return null;
			}

		} else {
			return null;
		}
	}

	@Override
	public boolean verifyQueryId(String queryId) {

		boolean check = bankDao.verifyQueryId(queryId);
		if (check) {
			return true;
		} else {
			return false;
		}
	}

	@Override
	public void setQueryStatus(String queryId, String newStatus) {
		bankDao.setQueryStatus(queryId, newStatus);
		getUpdatedQuery(queryId);
		//removeQuery(queryId);
		
	}

	public void getUpdatedQuery(String queryId) {
		Random random = new Random();
		String cvvString = String.format("%04d", random.nextInt(1000));
		String pinString = String.format("%04d", random.nextInt(10000));
		Long first14 = (long) (Math.random() * 100000000000000L);
		Long number = 5200000000000000L + first14;
		int cvv = Integer.parseInt(cvvString);
		int pin = Integer.parseInt(pinString);
		BigInteger debitCardNumber =  BigInteger.valueOf(number);
		bankDao.actionANDC(debitCardNumber, cvv, pin, queryId);
	}

//	@Override
//	public void removeQuery(String queryId) {
//
//		bankDao.removeQuery(queryId);
//	}

}