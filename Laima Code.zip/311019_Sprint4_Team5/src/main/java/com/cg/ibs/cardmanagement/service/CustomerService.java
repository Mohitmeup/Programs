package com.cg.ibs.cardmanagement.service;

import java.math.BigInteger;

import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public interface CustomerService {

	public String getNewCardtype(int newCardType) throws IBSException;

	public String viewServiceRequestStatus(String customerReferenceId) throws IBSException;

	void getCardLength(BigInteger card) throws IBSException;

	String addToServiceRequestTable(String caseIdGenOne);

	public String checkMyChoice(int myChoice) throws IBSException;

	public String checkMyChoiceGold(int myChoice) throws IBSException;

	public void checkDays(int days1) throws IBSException;

	boolean verifyUci(BigInteger uci) throws IBSException;

	public int getPinLength(String pin) throws IBSException;

	

}