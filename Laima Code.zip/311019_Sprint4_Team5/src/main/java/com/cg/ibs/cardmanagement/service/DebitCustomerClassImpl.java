package com.cg.ibs.cardmanagement.service;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

import com.cg.ibs.cardmanagement.bean.DebitCardBean;
import com.cg.ibs.cardmanagement.bean.DebitCardTransaction;
import com.cg.ibs.cardmanagement.dao.AccountDao;
import com.cg.ibs.cardmanagement.dao.AccountDaoImpl;
import com.cg.ibs.cardmanagement.dao.CaseIdDao;
import com.cg.ibs.cardmanagement.dao.CaseIdDaoImpl;
import com.cg.ibs.cardmanagement.dao.DebitCardDao;
import com.cg.ibs.cardmanagement.dao.DebitCardDaoImpl;
import com.cg.ibs.cardmanagement.dao.DebitCardTransactionDao;
import com.cg.ibs.cardmanagement.dao.DebitCardTransactionDaoImpl;
import com.cg.ibs.cardmanagement.exceptionhandling.ErrorMessages;
import com.cg.ibs.cardmanagement.exceptionhandling.IBSException;

public class DebitCustomerClassImpl extends CustomerServiceImpl implements DebitCustomer {

	CaseIdDao caseIdDao = new CaseIdDaoImpl();
	DebitCardTransactionDao debitCardTransactionDao = new DebitCardTransactionDaoImpl();

	DebitCardDao debitCardDao = new DebitCardDaoImpl();

	AccountDao accountDao = new AccountDaoImpl();

	@Override
	public List<DebitCardBean> viewAllDebitCards() throws IBSException {
		try {
			return debitCardDao.viewAllDebitCards();
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}

	}

	@Override
	public String requestDebitCardUpgrade(BigInteger debitCardNumber, String myChoice) throws IBSException {
		String status=null;
		try {
		status = debitCardDao.getDebitCardStatus(debitCardNumber);
		}catch (IBSException e) {
		throw new IBSException(ErrorMessages.NO_CARD_STATUS);
		}
		
		if (status.equals("Blocked")) {
			throw new IBSException(ErrorMessages.CARD_BLOCK_MESSAGE);
		} else {

			caseIdGenOne = "RDCU";
			timestamp = LocalDateTime.now();
			caseIdTotal = addToServiceRequestTable(caseIdGenOne);
			customerReferenceID = (caseIdTotal + random.nextInt(100));
			caseIdObj.setCaseIdTotal(caseIdTotal);
			caseIdObj.setCaseTimeStamp(timestamp);
			caseIdObj.setStatusOfServiceRequest("Pending");
			caseIdObj.setCardNumber(debitCardNumber);
			caseIdObj.setCustomerReferenceId(customerReferenceID);
			BigInteger accountNumber = debitCardDao.getAccountNumber(debitCardNumber);
			caseIdObj.setAccountNumber(accountNumber);

			caseIdObj.setUCI(accountDao.getUci(accountNumber));
			caseIdObj.setDefineServiceRequest(myChoice);

			try {
				caseIdDao.actionServiceRequest(caseIdObj);
			} catch (IBSException e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);
			}

			return (customerReferenceID);
		}
	}

	@Override
	public void resetDebitPin(BigInteger debitCardNumber, String pin) throws IBSException {
		try {

			debitCardDao.setNewDebitPin(debitCardNumber, pin);
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}

	}

	@Override
	public String applyNewDebitCard(BigInteger accountNumber, String newCardType) throws IBSException {
		caseIdGenOne = "ANDC";

		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
		customerReferenceID = (caseIdTotal + random.nextInt(100));

		caseIdObj.setDefineServiceRequest(newCardType);
		caseIdObj.setAccountNumber(accountNumber);
		caseIdObj.setCaseIdTotal(caseIdTotal);
		timestamp = LocalDateTime.now();
		caseIdObj.setCaseTimeStamp(timestamp);
		caseIdObj.setStatusOfServiceRequest("Pending");

		caseIdObj.setUCI(accountDao.getUci(accountNumber));

		caseIdObj.setCustomerReferenceId(customerReferenceID);
		caseIdDao.actionServiceRequest(caseIdObj);

		return customerReferenceID;

	}
	@Override
	public String getDebitcardType(BigInteger debitCardNumber) throws IBSException {
		String type;
		
			try {
				type = debitCardDao.getdebitCardType(debitCardNumber);
			} catch (IBSException e) {
				throw new IBSException(ErrorMessages.INTERNAL_ERROR);
			}

			return type;
		
	}
//	@Override
//	public String requestDebitCardLost(BigInteger debitCardNumber) throws IBSException {
//		caseIdGenOne = "RDCL";
//
//		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
//		customerReferenceID = (caseIdTotal + random.nextInt(100));
//
//		caseIdObj.setCaseIdTotal(caseIdTotal);
//		caseIdObj.setCaseTimeStamp(LocalDateTime.now());
//		caseIdObj.setStatusOfServiceRequest("Pending");
//
//		BigInteger accountNumber = debitCardDao.getAccountNumber(debitCardNumber);
//		caseIdObj.setAccountNumber(accountNumber);
//
//		caseIdObj.setUCI(accountDao.getUci(accountNumber));
//		caseIdObj.setCardNumber(debitCardNumber);
//		caseIdObj.setDefineServiceRequest("Blocked");
//		caseIdObj.setCustomerReferenceId(customerReferenceID);
//
//		try {
//			caseIdDao.actionServiceRequest(caseIdObj);
//		} catch (IBSException e) {
//			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
//		}
//
//		return (customerReferenceID);
//	}
	@Override

	public void requestDebitCardLost(BigInteger debitCardNumber) throws IBSException {



		try {

			debitCardDao.blockDebitCard(debitCardNumber);

		} catch (IBSException e) {

			throw new IBSException(ErrorMessages.INTERNAL_ERROR);

		}



	}
	@Override
	public String raiseDebitMismatchTicket(BigInteger transactionId) throws IBSException {

		caseIdGenOne = "RDMT";
		BigInteger debitCardNumber = debitCardTransactionDao.getDebitCardNumber(transactionId);
		timestamp = LocalDateTime.now();
		caseIdTotal = addToServiceRequestTable(caseIdGenOne);
		customerReferenceID = (caseIdTotal + random.nextInt(100));
		caseIdObj.setCaseIdTotal(caseIdTotal);
		caseIdObj.setCaseTimeStamp(timestamp);
		caseIdObj.setStatusOfServiceRequest("Pending");
		caseIdObj.setAccountNumber(debitCardDao.getDMAccountNumber(debitCardNumber));
		caseIdObj.setUCI(debitCardTransactionDao.getDMUci(transactionId));

		caseIdObj.setCardNumber(debitCardTransactionDao.getDebitCardNumber(transactionId));

		caseIdObj.setDefineServiceRequest("Transaction ID :" + transactionId);
		caseIdObj.setCustomerReferenceId(customerReferenceID);
		try {
			caseIdDao.actionServiceRequest(caseIdObj);
		} catch (IBSException e) {
			throw new IBSException(ErrorMessages.INTERNAL_ERROR);
		}

		return (customerReferenceID);

	}

	@Override
	public List<DebitCardTransaction> getDebitTransactions(int days, BigInteger debitCardNumber) throws IBSException {
		List<DebitCardTransaction> debitCardBeanTrns = debitCardTransactionDao.getDebitTrans(days, debitCardNumber);
		if (debitCardBeanTrns.isEmpty())
			throw new IBSException(ErrorMessages.NO_TRANSACTIONS_MESSAGE);
		return debitCardBeanTrns;

	}
}