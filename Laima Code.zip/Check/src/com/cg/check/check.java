package com.cg.check;

public class check {
	public static void main(String[] args) {
		String str="";
		String str1=null;
		System.out.println(str1.isEmpty());
	}

}
