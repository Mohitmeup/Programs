package com.cg.ibs.cardmanagement.dao;

public class DaoClass {
public CardManagement(){

    HashMap<String, ArrayList<String>> User_Details = new ArrayList<String, ArrayList<String>>();

	HashMap<String, > Customer_Details = new ArrayList<String, ArrayList<String>>();	

	HashMap<String, > Credit_Card_Details = new ArrayList<String, ArrayList<String>>();

	HashMap<String, > Debit_Card_Details = new ArrayList<String, ArrayList<String>>();

	HashMap<String, > Query_Type = new ArrayList<String, ArrayList<String>>();

	HashMap<String, > Query_Details = new ArrayList<String, ArrayList<String>>();

      CardService =new CardService();

    }


}
