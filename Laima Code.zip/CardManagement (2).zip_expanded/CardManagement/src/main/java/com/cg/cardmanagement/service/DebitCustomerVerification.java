package com.cg.cardmanagement.service;

import java.math.BigInteger;

import com.cg.cardmanagement.exception.IBSException;

public interface DebitCustomerVerification {

	public boolean verifyDebitPin(String pin, BigInteger debitCardNumber) throws IBSException;

	public boolean verifyDebitCardPin(String pin) throws IBSException;

}
