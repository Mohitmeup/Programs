package com.cg.cardmanagement.model;

import java.math.BigInteger;

public class CreditApply {
	private BigInteger uci;
	private String type;
	public BigInteger getUci() {
		return uci;
	}
	public void setUci(BigInteger uci) {
		this.uci = uci;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	@Override
	public String toString() {
		return "CreditApply [uci=" + uci + ", type=" + type + "]";
	}
	public CreditApply(BigInteger uci, String type) {
		super();
		this.uci = uci;
		this.type = type;
	}
	public CreditApply() {
		super();
	}
	

}
