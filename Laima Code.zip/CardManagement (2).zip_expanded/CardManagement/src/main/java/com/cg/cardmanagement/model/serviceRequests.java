package com.cg.cardmanagement.model;

import java.io.Serializable;

public class serviceRequests implements Serializable {

	private String bankAdminRemarks;
	private String caseIdTotal;
	private String statusOfServiceRequest;
	public String getBankAdminRemarks() {
		return bankAdminRemarks;
	}
	public void setBankAdminRemarks(String bankAdminRemarks) {
		this.bankAdminRemarks = bankAdminRemarks;
	}
	public String getCaseIdTotal() {
		return caseIdTotal;
	}
	public void setCaseIdTotal(String caseIdTotal) {
		this.caseIdTotal = caseIdTotal;
	}
	public String getStatusOfServiceRequest() {
		return statusOfServiceRequest;
	}
	public void setStatusOfServiceRequest(String statusOfServiceRequest) {
		this.statusOfServiceRequest = statusOfServiceRequest;
	}
	public serviceRequests() {
		super();
		// TODO Auto-generated constructor stub
	}
	public serviceRequests(String bankAdminRemarks, String caseIdTotal, String statusOfServiceRequest) {
		super();
		this.bankAdminRemarks = bankAdminRemarks;
		this.caseIdTotal = caseIdTotal;
		this.statusOfServiceRequest = statusOfServiceRequest;
	}
	@Override
	public String toString() {
		return "serviceRequests [bankAdminRemarks=" + bankAdminRemarks + ", caseIdTotal=" + caseIdTotal
				+ ", statusOfServiceRequest=" + statusOfServiceRequest + "]";
	}

	
}
