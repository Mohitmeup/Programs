package com.cg.cardmanagement.service;

import java.math.BigInteger;
import java.util.List;

import com.cg.cardmanagement.exception.IBSException;
import com.cg.cardmanagement.model.CaseIdBean;
import com.cg.cardmanagement.model.CreditCardTransaction;
import com.cg.cardmanagement.model.Transaction;

public interface BankService {

	public void setQueryStatus(String queryId, String newStatus, String remarks) throws IBSException;

	public String getNewQueryStatus(int newQueryStatus) throws IBSException;

	public void upgradeDC(String queryId) throws IBSException;

	public void getNewDC(String queryId) throws IBSException;

	public void upgradeCC(String queryId) throws IBSException;

	public List<CaseIdBean> viewNewDebitQueries(Integer bankerId) throws IBSException;

	public List<CaseIdBean> viewNewCreditQueries(Integer bankerId) throws IBSException;

	public List<CaseIdBean> viewDebitUpgradeQueries(Integer bankerId) throws IBSException;

	public List<CaseIdBean> viewCreditUgradeQueries(Integer bankerId) throws IBSException;

	public List<CaseIdBean> viewDebitMismatchQueries(Integer bankerId) throws IBSException;

	public List<CaseIdBean> viewCreditMismatchQueries(Integer bankerId) throws IBSException;

	public boolean getBlockInput(int blockInput, BigInteger debitCardNumber) throws IBSException;

	public boolean getBlockInputCredit(int blockInput, BigInteger creditCardNumber) throws IBSException;

	public CreditCardTransaction getCreditMismatchTransaction(Integer transactionId) throws IBSException;

	public boolean checkMismatchDebit(String queryId) throws IBSException;

	public Transaction getDebitMismatchTransaction(Integer mismatchTransactionId) throws IBSException;

	Integer getDebitTransactionId(String queryId) throws IBSException;

	public Integer getCreditTransactionId(String queryId) throws IBSException;

	boolean checkMismatchCredit(String queryId) throws IBSException;

	void blockDebit(BigInteger debitCardNumber) throws IBSException;

	void blockCredit(BigInteger creditCardNumber) throws IBSException;

	public boolean checkCardBlock(BigInteger creditCardNumber) throws IBSException;

	void getNewCC(String queryId) throws IBSException;

	

	public List<CaseIdBean> viewCustomerHistory(BigInteger uci) throws IBSException;

	public void setBankTimeStamp(String serviceRequest);
}