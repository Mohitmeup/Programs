package com.cg.cardmanagement.dao;

import java.math.BigInteger;
import java.time.LocalDateTime;
import java.util.List;

import com.cg.cardmanagement.exception.IBSException;
import com.cg.cardmanagement.model.CaseIdBean;

public interface CaseIdDao {

	String getNewType(String queryId) throws IBSException;

	void setQueryStatus(String queryId, String newStatus, String remarks, LocalDateTime localDateTime) throws IBSException;

	boolean verifyQueryId(String queryId) throws IBSException;

	BigInteger getNewUCI(String queryId) throws IBSException;

	void actionServiceRequest(CaseIdBean caseIdObj) throws IBSException;

	String getCustomerReferenceStatus(CaseIdBean caseIdObj, String customerReferenceId) throws IBSException;

	CaseIdBean getCaseObj(String queryId) throws IBSException;

	List<CaseIdBean> viewCreditMismatchQueries(Integer bankerId) throws IBSException;

	List<CaseIdBean> viewDebitMismatchQueries(Integer bankerId) throws IBSException;

	List<CaseIdBean> viewCreditUpgradeQueries(Integer bankerId) throws IBSException;

	List<CaseIdBean> viewDebitUpgradeQueries(Integer bankerId) throws IBSException;

	List<CaseIdBean> viewNewCreditQueries(Integer bankerId) throws IBSException;

	List<CaseIdBean> viewNewdebitQueries(Integer bankerId) throws IBSException;

	List<CaseIdBean> viewAllServiceRequests() throws IBSException;

	

	List<CaseIdBean> viewCustomerHistory(BigInteger uci) throws IBSException;

	BigInteger getApplicationId()throws IBSException;

	void setMismatchQueryTimeStamp(String serviceRequest, LocalDateTime now);

}
