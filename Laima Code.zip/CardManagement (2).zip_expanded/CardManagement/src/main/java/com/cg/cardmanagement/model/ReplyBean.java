package com.cg.cardmanagement.model;

import java.math.BigInteger;

public class ReplyBean {
	private BigInteger cardNumber;
	private String answer;
	public BigInteger getCardNumber() {
		return cardNumber;
	}
	public void setCardNumber(BigInteger cardNumber) {
		this.cardNumber = cardNumber;
	}
	public String getAnswer() {
		return answer;
	}
	public void setAnswer(String answer) {
		this.answer = answer;
	}
	@Override
	public String toString() {
		return "ReplyBean [cardNumber=" + cardNumber + ", answer=" + answer + "]";
	}
	public ReplyBean() {
		super();
	}
	public ReplyBean(BigInteger cardNumber, String answer) {
		super();
		this.cardNumber = cardNumber;
		this.answer = answer;
	}
	
}
