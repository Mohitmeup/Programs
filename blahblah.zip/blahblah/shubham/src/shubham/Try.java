package shubham;

public class Try {
	public static void main(String[] args) {
		double a = 1000.00;
		int b = 10*10*10;
System.out.println(a==b);		
	}
}
