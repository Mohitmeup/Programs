package com.cg.calculation.ui;

import java.util.Date;
import java.util.Iterator;
import java.util.Scanner;

import com.cg.calculation.service.ArmstrongService;
import com.cg.calculation.service.ClientService;
import com.cg.calculation.service.VerificationService;

public class WelcomeUser {

	public static void main(String[] args) {
		Scanner seriesLength = new Scanner(System.in);
		System.out.println(" \nEnter the number of elements required in the series");
		int n = seriesLength.nextInt();

		VerificationService verificationService = new VerificationService();
		if (verificationService.verification(n)) {

			System.out.println(" \nInput Accepted\nDisplaying Fibonacci Series Below\n");
			ClientService Obj = new ClientService();
			double fibArray[] = Obj.fibonacciSeries(n);
			for (double d : fibArray) {
				System.out.print(d+"  ");
			}
			fibArray[7]=153;
			System.out.println("\n\nDisplaying the armstrong numbers\n");
			ArmstrongService Obj1 = new ArmstrongService(); // Creating
			double output[] = Obj1.arm(fibArray);

			for (int i = 0, j = 5; i < output.length; i++, j++) {
				if (output[i] == 0.0) {
					System.out.println(fibArray[j] + "  is not amstrong number");
				} else if (output[i] == 1.0) {
					System.out.println(fibArray[j] + "  is an amstrong number");
				}
			}
		} else {
			System.out.println("enterted input is Incorect");
		}
	}
}
