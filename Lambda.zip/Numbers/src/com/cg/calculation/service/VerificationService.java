package com.cg.calculation.service;

public class VerificationService {
	public boolean verification(int n) {
		boolean result=false;
		if (n < 30 || n > 0) {
			result=true;
		}
		return result;
	}
}
