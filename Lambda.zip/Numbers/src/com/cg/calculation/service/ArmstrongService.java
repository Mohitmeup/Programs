package com.cg.calculation.service;

public class ArmstrongService {
	private double c = 0.0;
	private double a = 0.0;

	public double[] arm(double[] b) {
		int arrLength=(b.length>10) ? 10 : b.length;
		double output[]=new double[5];
		int j=0;
		
		for (int i = 5; i < arrLength ; i++,j++) { // Check for the 5th to 10th element
			double m = b[i]; // Temp storage
				while (m > 0) {
					a = m % 10;
					m = m / 10;
					c = c + Math.pow(a, 3);
				}
				if (c==b[i]) {
						output[j] = 1;
						
				} else {
					output[j] = 0;
				}
			}
		return output;
	}
}
