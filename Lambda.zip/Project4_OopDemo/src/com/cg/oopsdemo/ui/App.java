package com.cg.oopsdemo.ui;

import com.cg.oopsdemo.model.Rectangle;

public class App {
	public static void main(String[] args) {

		Rectangle r1 = new Rectangle();

		r1.setLength(10);
		r1.setBreadth(20);

		System.out.print(r1.getLength());
		System.out.println("  " + r1.getBreadth());

		Rectangle r2 = new Rectangle(30, 40);
		System.out.print(r2.getLength());
		System.out.println("  " + r2.getBreadth());

		Rectangle r3 = r1;
		System.out.print(r3.getLength());
		System.out.println("  " + r3.getBreadth());-

		r3.setLength(50);
		System.out.println(r1.getLength());

		Rectangle r4 = new Rectangle(r1);
		System.out.print(r4.getLength());
		System.out.println("  " + r4.getBreadth());

		r4.setLength(100);
		System.out.print(r4.getLength());
		System.out.println(" " + r1.getLength());
	}
}
