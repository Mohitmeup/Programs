package com.cg.oopsdemo.model;

public class Rectangle {
	private int length;
	private int breadth;

	public Rectangle() {
	}

	public Rectangle(Rectangle r) {
		r.length = 1000;
		this.length = r.length;
		this.breadth = r.breadth;
	}

	public Rectangle(int length, int breadth) {
		super();
		this.length = length;
		this.breadth = breadth;
	}

	public int getLength() {
		return length;
	}

	public void setLength(int length) {
		this.length = length;
	}

	public int getBreadth() {
		return breadth;
	}

	public void setBreadth(int breadth) {
		this.breadth = breadth;
	}

}
