
package com.cg.dw.model;

public enum TransactionMode {


	ONLINE, CASH;
}

