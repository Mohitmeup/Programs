package com.cg.lambda;

@FunctionalInterface
public interface Dummy {
public int doProcess(int i);
//public void nasty();
}
