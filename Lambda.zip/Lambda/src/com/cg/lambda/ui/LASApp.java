package com.cg.lambda.ui;

import java.util.ArrayList;
import java.util.List;

import com.cg.lambda.Book;

public class LASApp {
	
public static void main(String[] args) {
	 List<Book> booklist = new ArrayList<>();
	 booklist.
	 
		 
	 }
			 
	
}

