package com.cg.bankdetails.bean;

public class Account {
 private long AccNum;
 private long BranchId;
 private double Balance;
 private long PinCode;
public long getAccNum() {
	return AccNum;
}
public void setAccNum(long accNum) {
	AccNum = accNum;
}
public long getBranchId() {
	return BranchId;
}
public void setBranchId(long branchId) {
	BranchId = branchId;
}
public double getBalance() {
	return Balance;
}
public void setBalance(double balance) {
	Balance = balance;
}
public long getPinCode() {
	return PinCode;
}
public void setPinCode(long pinCode) {
	PinCode = pinCode;
}
 
}
