package com.cg.bankdetails.ui;

import java.util.Scanner;

import com.cg.bankdetails.bean.Account;
import com.cg.bankdetails.service.Service;

public class UserInterface{

	public static void main(String[] args) {
		Scanner read = new Scanner(System.in);
		Service service = new Service();
		
		int input3 = 0;
		do{
		System.out.println("Enter requirement.\n To Eneter Bank Details press 1");
		int input = read.nextInt();
		Account account = new Account();
		
		if (input == 1) {
			System.out.println(" Enter Below Details.\n Account No (8 digits)");
			long accNum = read.nextLong();
			System.out.println(" Branch Id (5 digits)");
			long branchId = read.nextLong();
			System.out.println(" Balance");
			double bal = read.nextDouble();
			System.out.println(" Pin Code (5 digits)");
			long pinCode = read.nextLong();
			int temp = service.verification(accNum, branchId, bal, pinCode);
							if (temp == 4){
					System.out.println("All inputs are verified");
					account.setAccNum(accNum);
					account.setBranchId(branchId);
					account.setBalance(bal);
					account.setPinCode(pinCode);
						service.callDetails(account);
						System.out.println("Press 3 to add more details, else 0");
						 input3 = read.nextInt();
				}else{
					System.out.println("Enter Again");
				}}}while(input3 == 3);
			System.out.println("Enter 2 for Show Details");
			int input2;
			 input2 = read.nextInt(); 
		
		if (input2 == 2){
			System.out.println(" Displaying Details.");
			
			for(Account a:service.printDetails()){
				if (a != null)
				System.out.println("Account no =" +a.getAccNum()+  "   Branch Id=   " +a.getBranchId() +"    Balance = " +a.getBalance()+ "   Pin Code =" +a.getPinCode());
			}
		}
		 
		 read.close();
	}
}
