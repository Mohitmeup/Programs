package com.cg.bankdetails.service;

import com.cg.bankdetails.bean.Account;
import com.cg.bankdetails.dao.BankDao;

public class Service {
	BankDao getdetails = new BankDao();
	Account[] detailarray = new Account[5];
	int num = 0;
	public int verification(long AccNum, long BranchId, double Bal, long PinCode) {
		int count = 0;
		double c = Math.pow(10, 7);
		double a = AccNum / c;
		count = (a < 10 && a >= 1) ? 1 : 0;

		c = Math.pow(10, 4);
		a = BranchId / c;
		if (a < 10 && a >= 1) {
			count++;
		}

		if (Bal > 0) {
			count++;
		}

		c = Math.pow(10, 4);
		a = PinCode / c;
		if (a < 10 && a >= 1) {
			count++;
		}

		return count;
	}
public void callDetails (Account account) {
	getdetails.setDetails(detailarray);
	getdetails.saveDetails(account, num);
	num++;
}
	public Account[] printDetails() {
		return getdetails.getDetails();
	}
}
