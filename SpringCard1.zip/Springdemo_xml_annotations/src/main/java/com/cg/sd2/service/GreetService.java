package com.cg.sd2.service;

public interface GreetService {
	String greet(String username);

}
