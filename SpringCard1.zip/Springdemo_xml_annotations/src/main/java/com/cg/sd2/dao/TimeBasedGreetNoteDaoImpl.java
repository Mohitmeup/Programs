package com.cg.sd2.dao;

import java.time.LocalDateTime;

import org.springframework.stereotype.Repository;
@Repository
public class TimeBasedGreetNoteDaoImpl implements GreetNoteDao {

	public String getGreetNote() {
		String result = null;
		int hour = LocalDateTime.now().getHour();
		if(hour >= 4 && hour <= 10) {
			result = "Good Morning ";
		} else if (hour <= 16) {
			result = "Good Afternoon ";
			
		} else {
			result = "Good Ebening ";
		}
		return result;
	}

}
