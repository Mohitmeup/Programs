package com.cg.sd2.dao;

public interface GreetNoteDao {
	String getGreetNote();

}
