package com.cg.sd2.ui;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Component;

import com.cg.sd2.service.GreetService;

@Component
public class App {
	
	@Autowired
private GreetService service;
	
	public static void main(String[] args) {

		ApplicationContext context = new ClassPathXmlApplicationContext("beans.xml");
		App app = (App)context.getBean("app");
		System.out.println(app.service.greet("Mohit"));
	}

}
