package com.cg.sd2.service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.sd2.dao.GreetNoteDao;
@Service
public class AdvancedGreetServiceImpl implements GreetService {

	@Autowired
	private GreetNoteDao dao;

	public GreetNoteDao getDao() {
		return dao;
	}

	public void setDao(GreetNoteDao dao) {
		this.dao = dao;
	}

	@Override
	public String greet(String username) {
		return dao.getGreetNote() + username;
	}

}
