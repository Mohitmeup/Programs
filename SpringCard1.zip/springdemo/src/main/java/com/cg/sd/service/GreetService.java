package com.cg.sd.service;

public interface GreetService {
	String greet(String userName);
}
