package com.cg.sd.service;

public class GreetServiceSimpleImpl implements GreetService {

	@Override
	public String greet(String userName) {
		return "Hello " + userName;
	}

}
