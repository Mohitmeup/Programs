package com.cg.st.service;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {

	public static void main(String[] args) {
//		SimpleGreetServiceImpl gs = new SimpleGreetServiceImpl();
		
		ApplicationContext gtc = new ClassPathXmlApplicationContext("myBeans.xml");
		GreetService gs = (GreetService) gtc.getBean("ags");
		System.out.println(gs.greet("Divye56"));
		
		GreetService gs3 = (GreetService) gtc.getBean("pgs");
		System.out.println(gs3.greet("Divye12"));
		
		GreetService gs2 = (GreetService) gtc.getBean("pgs");
		((ParamedGreetServiceImpl)gs2).setGreetNote("NAMASKAR ");
		
		System.out.println(gs2.greet("Divye1"));
		
		GreetService gs4 = (GreetService) gtc.getBean("pgs");
		System.out.println(gs4.greet("Divye12"));
	}

}
