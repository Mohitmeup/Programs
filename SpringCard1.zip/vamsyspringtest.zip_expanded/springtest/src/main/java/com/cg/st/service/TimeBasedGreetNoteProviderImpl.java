package com.cg.st.service;

import java.time.LocalDateTime;

public class TimeBasedGreetNoteProviderImpl implements GreetNoteProvider {

	public String getGreetNote() {
		String result = null;
		int hour = LocalDateTime.now().getHour();
		if(hour >= 4 && hour <= 11) {
			result = "Good Morning ";
		} else if (hour <= 16) {
			result = "Good Afternoon ";
			
		} else {
			result = "Good Ebening ";
		}
		return result;
	}

}
