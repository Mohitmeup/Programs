package com.cg.st.service;

public class ParamedGreetServiceImpl implements GreetService {
	private String greetNote;

	public String greet(String username) {
		return greetNote + username;
	}

	public String getGreetNote() {
		return greetNote;
	}

	public void setGreetNote(String greetNote) {
		this.greetNote = greetNote;
	}

}
