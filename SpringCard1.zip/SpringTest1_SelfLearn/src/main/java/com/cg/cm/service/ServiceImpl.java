package com.cg.cm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.cm.dao.Dao;
@Component
public class ServiceImpl implements Service {
	
	@Autowired
	Dao dao;

	@Override
	public boolean verifyAccountNumber(int accountNumber) {
		boolean result = false;
		if (dao.checkAccountNumber(accountNumber)) {
			result = true;
		}
		return result;
	}

}
