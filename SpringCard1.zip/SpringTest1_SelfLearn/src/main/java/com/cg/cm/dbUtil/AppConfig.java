package com.cg.cm.dbUtil;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages="com.cg.cm")
public class AppConfig {
}
