package com.cg.cm.ui;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.cg.cm.service.ServiceImpl;

public class UI {

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int accountNumber;
		ApplicationContext context = new AnnotationConfigApplicationContext("AppConfig.class");
		ServiceImpl service1 = (ServiceImpl)context.getBean("service");
		System.out.println("Enter Account Number");
		accountNumber = scan.nextInt();
		if(service1.verifyAccountNumber(accountNumber)) {
			System.out.println("TRUE");
		}
		else {
			System.out.println("FALSE");
		}
	
		}

}
