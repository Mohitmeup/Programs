package com.cg.cm.dao;

import org.springframework.stereotype.Component;

@Component
public class DaoImpl implements Dao {

	@Override
	public boolean checkAccountNumber(int accountNumber) {
		boolean result = false;
		if (accountNumber == 123) {
			result = true;
		}
		return result;
	}
}
