package com.cg.cm.service;

public interface Service {

	boolean verifyAccountNumber(int accountNumber);
}
