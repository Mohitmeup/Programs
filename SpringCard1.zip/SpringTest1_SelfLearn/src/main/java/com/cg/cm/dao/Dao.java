package com.cg.cm.dao;

public interface Dao {
	public boolean checkAccountNumber(int accountNumber);
}
