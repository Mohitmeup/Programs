package com.cg.ibs.cardmanagement.dao;

public class SqlQueries {

	public static final String SELECT_DATA_FROM_CREDIT_CARD = "select c from CreditCardBean c";
	public static final String SELECT_DATA_FROM_DEBIT_CARD = "select d from DebitCardBean d";

	public static final String VERIFY_DEBIT_CARD_NUM = "Select d from DebitCardBean d  where d.debitCardNumber=?1";

	public static final String SELECT_DATA_FROM_SERVICE_REQUEST = "Select d from CaseIdBean d where d.statusOfServiceRequest not in ('Approved') and d.statusOfServiceRequest not in ('Disapproved')";
	public static final String SELECT_FROM_DEBIT_CARD ="select d from DebitCardBean d where d.cardStatus  IN (:num)";
	public static final String SELECT_DATA_FROM_ACCOUNT = "select a from AccountBean a";
	public static final String SELECT_FROM_CREDIT_CARDS = "select d from CreditCardBean d where d.cardStatus IN (:num)";

}