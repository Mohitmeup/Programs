package selenium;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ClassFirst {
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "Drivers/chromedriver.exe");
		WebDriver driver = new ChromeDriver();
		driver.get("C:\\Users\\MOPURSNA\\Music\\SeleniumDemo\\pages\\NewFile.html");
		String title = driver.getTitle();
		if ("moht".contentEquals(title)) {
			System.out.println("Success");
		} else {
			System.out.println("Failure");
		}
		Thread.currentThread().sleep(2500);
		driver.close();
	}
}
